# AirTroller Pro v2.0.0

Enhanced AirDrop spam tool with advanced features - Phiên bản nâng cấp của AirTroller gốc!

## Tính năng mới so với AirTroller gốc

| Tính năng | AirTroller Gốc | AirTroller Pro |
|-----------|---------------|----------------|
| Gửi AirDrop spam | ✅ | ✅ |
| Chọn ảnh tùy chỉnh | ✅ | ✅ |
| **Burst Mode** | ❌ | ✅ Spam không ngừng nghỉ |
| **5 Speed Modes** | ❌ (chỉ có slider) | ✅ Slow/Normal/Fast/Turbo/Burst |
| **Multi-File Queue** | ❌ | ✅ Luân phiên nhiều ảnh |
| **Real-time Stats** | ❌ (chỉ đếm) | ✅ Dashboard đầy đủ |
| **Device Name Spoof** | ❌ | ✅ Ẩn danh |
| **Auto-Retarget** | ❌ | ✅ Tự động tìm mục tiêu mới |
| **7 Preset Images** | ❌ (1 ảnh) | ✅ 7 ảnh built-in |
| **Modern UI** | Cơ bản | Đẹp, dark mode, animation |

## Yêu cầu

- iOS 14.0 trở lên
- TrollStore hoặc Jailbreak
- Bluetooth và WiFi bật

## Cách cài đặt .tipa

### Cách 1: Dùng GitHub Actions (KHÔNG cần máy Mac!)

1. **Fork repo này** về GitHub của bạn
2. Vào tab **Actions** → chọn workflow **Build AirTroller Pro .tipa**
3. Click **Run workflow**
4. Chờ ~5 phút, file .tipa sẽ xuất hiện trong **Releases**!
5. Tải file .tipa về iPhone → Mở bằng TrollStore → Install

### Cách 2: Build trên macOS với Xcode

```bash
# 1. Clone repo
git clone https://github.com/yourname/AirTrollerPro.git
cd AirTrollerPro

# 2. Mở Xcode project
open AirTrollerPro.xcodeproj

# 3. Trong Xcode:
#    - Chọn team Signing
#    - Build (Cmd+B)
#    - Product → Archive
#    - Export .ipa

# 4. Đổi .ipa thành .tipa
mv AirTrollerPro.ipa AirTrollerPro.tipa

# 5. AirDrop hoặc copy sang iPhone, mở bằng TrollStore
```

### Cách 3: Build dùng Theos (Jailbreak)

```bash
# 1. Cài Theos
bash -c "$(curl -fsSL https://raw.githubusercontent.com/theos/theos/master/bin/install-theos)"

# 2. Build
cd AirTrollerPro
make package

# 3. File .tipa sẽ nằm trong packages/
```

## Cách sử dụng

1. **Mở app** → Tự động quét thiết bị xung quanh
2. **Chọn mục tiêu** → Tap vào thiết bị (viền cam = đã chọn)
3. **Chọn chế độ tốc độ**:
   - 🐢 Slow: 2s/lần - An toàn, khó bị phát hiện
   - 🐰 Normal: 0.8s/lần - Cân bằng
   - ⚡ Fast: 0.35s/lần - Khó chịu max
   - ⚡🔥 Turbo: 0.15s/lần - Màn hình hiện liên tục
   - 🔥 BURST: 0.05s/lần - Không ngừng nghỉ!
4. **Chọn ảnh** (tuỳ chọn):
   - Ảnh có sẵn: Troll Face, Shocked, Rage, LOL, WTF, Deal With It, Mind Blown
   - Ảnh tùy chỉnh: Chọn từ thư viện ảnh
   - Multi-file queue: Luân phiên nhiều ảnh
5. **Nhấn "BẮT ĐẦU SPAM"** 🔥
6. **Xem stats** real-time trong tab thống kê

## Cài đặt nâng cao

Vào **Cài đặt nâng cao** (icon bánh răng):
- **Burst Mode**: Bật để spam cực nhanh
- **Auto-Retarget**: Tự động spam thiết bị mới
- **Queue Mode**: Gửi luân phiên nhiều file
- **Tên thiết bị giả**: Ẩn tên thật của bạn

## Lưu ý quan trọng

⚠️ **Chỉ dùng để troll bạn bè!** Không spam ngườilạ!

⚠️ Nạn nhân có thể tắt AirDrop hoặc chuyển sang "Contacts Only"

⚠️ Spam quá nhiều có thể bị chặn AirDrop tạm thờ (cooldown ~5 phút)

⚠️ Một số phiên bản iOS 16+ có thể chống spam tốt hơn

## File trong project

```
AirTrollerPro/
├── AirTrollerPro/
│   ├── AirTrollerProApp.swift      # App entry + managers
│   ├── ContentView.swift           # Main UI
│   ├── AdvancedSettingsView.swift  # Settings
│   ├── StatsView.swift             # Statistics dashboard
│   ├── PresetImagesView.swift      # Preset image picker
│   ├── BurstModeView.swift         # Burst mode interface
│   ├── Info.plist                  # App configuration
│   └── AirTrollerPro-Bridging-Header.h
├── trolldrop/
│   ├── TrollController.swift       # Core AirDrop engine
│   ├── Sharing.swift               # Private framework APIs
│   └── Person.swift
├── Misc/
│   ├── Alert.swift                 # Alert helpers
│   ├── Extensions.swift            # Swift extensions
│   ├── ImagePickerView.swift       # Photo picker
│   ├── RemoteLog.h                 # Debug logging
│   └── TS/                         # TrollStore utilities
│       ├── TSUtil.h
│       ├── TSUtil.m
│       └── CoreServices.h
├── Resources/
│   └── Trollface.png               # Default troll image
├── Makefile                        # Theos build config
├── control                         # Package metadata
├── AirTrollerPro.entitlements      # Special permissions
├── create_project.sh               # Project setup script
└── .github/workflows/build.yml     # GitHub Actions CI
```

## License

GPL-3.0 - Dựa trên AirTroller gốc của sourcelocation

## Credits

- **Original**: [sourcelocation/AirTroller](https://github.com/sourcelocation/AirTroller)
- **TrollDrop**: midnightchip (phương pháp ban đầu)
- **TrollStore**: opa334
- **Enhanced by**: AI + Community

---

**Enjoy trolling responsibly!** 🎭🔥
