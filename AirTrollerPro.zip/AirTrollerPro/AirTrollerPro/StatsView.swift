//
//  StatsView.swift
//  AirTroller Pro
//
//  Real-time statistics dashboard
//

import SwiftUI

struct StatsView: View {
    @Environment(\.presentationMode) var presentationMode
    @ObservedObject private var stats = StatsManager.shared
    
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(spacing: 20) {
                    // Header status
                    statusHeader
                    
                    // Main stats grid
                    statsGrid
                    
                    // Live rate chart (simulated)
                    if stats.isTracking {
                        liveRateSection
                    }
                    
                    // Session timeline
                    sessionTimeline
                    
                    // Efficiency metrics
                    efficiencyMetrics
                }
                .padding()
            }
            .navigationTitle("Thống kê")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Xong") {
                        presentationMode.wrappedValue.dismiss()
                    }
                    .fontWeight(.bold)
                    .foregroundColor(.orange)
                }
            }
        }
    }
    
    private var statusHeader: some View {
        HStack {
            VStack(alignment: .leading, spacing: 4) {
                Text(stats.isTracking ? "ĐANG SPAM" : "SẴN SÀNG")
                    .font(.caption)
                    .fontWeight(.black)
                    .foregroundColor(stats.isTracking ? .red : .green)
                
                if stats.isTracking, let startTime = stats.sessionStartTime {
                    Text("Bắt đầu: \(formatTime(startTime))")
                        .font(.caption2)
                        .foregroundColor(.secondary)
                }
            }
            
            Spacer()
            
            // Status indicator
            HStack(spacing: 6) {
                Circle()
                    .fill(stats.isTracking ? Color.red : Color.green)
                    .frame(width: 10, height: 10)
                    .modifier(stats.isTracking ? PulseEffect() : AnyViewModifier(EmptyView()))
                Text(stats.formattedDuration)
                    .font(.title3)
                    .fontWeight(.bold)
                    .monospacedDigit()
            }
        }
        .padding()
        .background(Color(UIColor.secondarySystemFill))
        .cornerRadius(16)
    }
    
    private var statsGrid: some View {
        LazyVGrid(columns: [
            GridItem(.flexible()),
            GridItem(.flexible())
        ], spacing: 12) {
            BigStatCard(
                value: "\(stats.totalSends)",
                label: "Tổng lần gửi",
                icon: "paperplane.fill",
                color: .orange,
                isAnimated: stats.isTracking
            )
            
            BigStatCard(
                value: "\(stats.totalTargets)",
                label: "Thiết bị bị spam",
                icon: "iphone.radiowaves.left.and.right.circle.fill",
                color: .red,
                isAnimated: false
            )
            
            BigStatCard(
                value: "\(Int(stats.currentSpamRate))",
                label: "Lần/phút (hiện tại)",
                icon: "bolt.fill",
                color: .green,
                isAnimated: stats.isTracking
            )
            
            BigStatCard(
                value: "\(Int(stats.peakSpamRate))",
                label: "Lần/phút (cao nhất)",
                icon: "crown.fill",
                color: .purple,
                isAnimated: false
            )
        }
    }
    
    private var liveRateSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Tốc độ thờigian thực")
                .font(.headline)
                .fontWeight(.bold)
            
            // Simulated bar chart
            HStack(alignment: .bottom, spacing: 4) {
                ForEach(0..<20) { i in
                    RoundedRectangle(cornerRadius: 2)
                        .fill(barColor(for: i))
                        .frame(height: barHeight(for: i))
                }
            }
            .frame(height: 60)
            .padding(.vertical, 8)
        }
        .padding()
        .background(Color(UIColor.secondarySystemFill))
        .cornerRadius(16)
    }
    
    private var sessionTimeline: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Phiên làm việc")
                .font(.headline)
                .fontWeight(.bold)
            
            HStack {
                TimelineItem(icon: "play.circle.fill", title: "Bắt đầu", 
                           value: stats.sessionStartTime != nil ? "Đã bắt đầu" : "Chưa bắt đầu",
                           color: .green)
                TimelineItem(icon: "paperplane.circle.fill", title: "Spam",
                           value: "\(stats.totalSends) lần", color: .orange)
                TimelineItem(icon: "stop.circle.fill", title: "Kết thúc",
                           value: stats.isTracking ? "Đang chạy..." : "Sẵn sàng", color: .red)
            }
        }
        .padding()
        .background(Color(UIColor.secondarySystemFill))
        .cornerRadius(16)
    }
    
    private var efficiencyMetrics: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Hiệu suất")
                .font(.headline)
                .fontWeight(.bold)
            
            VStack(spacing: 10) {
                MetricBar(label: "Tốc độ trung bình", 
                         value: stats.sessionDuration > 0 ? Double(stats.totalSends) / (stats.sessionDuration / 60.0) : 0,
                         maxValue: 100,
                         color: .blue)
                
                MetricBar(label: "Hiệu quả spam",
                         value: stats.totalSends > 0 ? Double(stats.totalTargets) / Double(stats.totalSends) * 100 : 0,
                         maxValue: 100,
                         color: .green)
            }
        }
        .padding()
        .background(Color(UIColor.secondarySystemFill))
        .cornerRadius(16)
    }
    
    // MARK: - Helpers
    private func formatTime(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "HH:mm:ss"
        return formatter.string(from: date)
    }
    
    private func barHeight(for index: Int) -> CGFloat {
        guard stats.isTracking else { return 4 }
        let baseHeight: CGFloat = 4
        let randomFactor = CGFloat.random(in: 0...1)
        let rateFactor = CGFloat(stats.currentSpamRate / max(stats.peakSpamRate, 1))
        return baseHeight + (50 * randomFactor * rateFactor) + 4
    }
    
    private func barColor(for index: Int) -> Color {
        let height = barHeight(for: index)
        if height > 40 { return .red }
        if height > 25 { return .orange }
        return .green
    }
}

// MARK: - Big Stat Card
struct BigStatCard: View {
    let value: String
    let label: String
    let icon: String
    let color: Color
    let isAnimated: Bool
    
    var body: some View {
        VStack(spacing: 8) {
            HStack {
                Image(systemName: icon)
                    .foregroundColor(color)
                Spacer()
            }
            
            Text(value)
                .font(.title2)
                .fontWeight(.black)
                .foregroundColor(.primary)
                .lineLimit(1)
                .minimumScaleFactor(0.5)
            
            Text(label)
                .font(.caption)
                .foregroundColor(.secondary)
                .multilineTextAlignment(.center)
        }
        .padding()
        .frame(maxWidth: .infinity, minHeight: 100)
        .background(Color(UIColor.tertiarySystemFill))
        .cornerRadius(16)
        .overlay(
            RoundedRectangle(cornerRadius: 16)
                .stroke(color.opacity(0.2), lineWidth: 1)
        )
    }
}

// MARK: - Timeline Item
struct TimelineItem: View {
    let icon: String
    let title: String
    let value: String
    let color: Color
    
    var body: some View {
        VStack(spacing: 6) {
            Image(systemName: icon)
                .font(.title2)
                .foregroundColor(color)
            Text(title)
                .font(.caption2)
                .foregroundColor(.secondary)
            Text(value)
                .font(.caption)
                .fontWeight(.semibold)
                .foregroundColor(.primary)
        }
        .frame(maxWidth: .infinity)
    }
}

// MARK: - Metric Bar
struct MetricBar: View {
    let label: String
    let value: Double
    let maxValue: Double
    let color: Color
    
    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            HStack {
                Text(label)
                    .font(.caption)
                    .foregroundColor(.secondary)
                Spacer()
                Text(String(format: "%.1f", value))
                    .font(.caption)
                    .fontWeight(.bold)
                    .foregroundColor(color)
            }
            
            GeometryReader { geometry in
                ZStack(alignment: .leading) {
                    RoundedRectangle(cornerRadius: 4)
                        .fill(Color(UIColor.tertiarySystemFill))
                        .frame(height: 8)
                    
                    RoundedRectangle(cornerRadius: 4)
                        .fill(color)
                        .frame(width: CGFloat(min(value / maxValue, 1.0)) * geometry.size.width, height: 8)
                        .animation(.easeInOut(duration: 0.5), value: value)
                }
            }
            .frame(height: 8)
        }
    }
}

// MARK: - AnyViewModifier for conditional modifiers
struct AnyViewModifier: ViewModifier {
    let view: AnyView
    
    init<V: View>(_ view: V) {
        self.view = AnyView(view)
    }
    
    func body(content: Content) -> some View {
        view
    }
}
