//
//  AirTrollerProApp.swift
//  AirTroller Pro
//
//  Enhanced version with advanced spam features
//

import SwiftUI

@main
struct AirTrollerProApp: App {
    @UIApplicationDelegateAdaptor(AppDelegate.self) var appDelegate
    
    var body: some Scene {
        WindowGroup {
            ContentView()
                .onAppear {
                    checkPermissions()
                    cleanupTempDirectory()
                }
        }
    }
    
    func checkPermissions() {
        // Check if user has root access (TrollStore/Jailbreak)
        do {
            _ = try FileManager.default.contentsOfDirectory(at: URL(fileURLWithPath: "/var/mobile"), includingPropertiesForKeys: nil)
        } catch {
            UIApplication.shared.alert(body: "AirTroller Pro requires TrollStore or Jailbreak to function properly.\n\nError: \(error.localizedDescription)", withButton: false)
        }
    }
    
    func cleanupTempDirectory() {
        // Clean up tmp dir on startup
        for url in (try? FileManager.default.contentsOfDirectory(at: FileManager.default.temporaryDirectory, includingPropertiesForKeys: nil)) ?? [] {
            try? FileManager.default.removeItem(at: url)
        }
    }
}

// MARK: - App Delegate for additional control
class AppDelegate: NSObject, UIApplicationDelegate {
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]? = nil) -> Bool {
        // Configure appearance
        UINavigationBar.appearance().tintColor = .systemOrange
        return true
    }
    
    func applicationWillTerminate(_ application: UIApplication) {
        // Cleanup when app closes
        NotificationCenter.default.post(name: NSNotification.Name("CleanupOnExit"), object: nil)
    }
}

// MARK: - Remote Logging
func remLog(_ objs: Any...) {
    for obj in objs {
        let args: [CVarArg] = [ String(describing: obj) ]
        withVaList(args) { RLogv("%@", $0) }
    }
}

// MARK: - Global Stats Manager
class StatsManager: ObservableObject {
    static let shared = StatsManager()
    
    @Published var totalSends: Int = 0
    @Published var totalTargets: Int = 0
    @Published var sessionStartTime: Date?
    @Published var peakSpamRate: Double = 0
    @Published var currentSpamRate: Double = 0
    @Published var targetsHit: Set<String> = []
    @Published var isTracking: Bool = false
    
    private var rateCounter: Int = 0
    private var rateTimer: Timer?
    
    func startTracking() {
        isTracking = true
        sessionStartTime = Date()
        rateCounter = 0
        currentSpamRate = 0
        
        rateTimer = Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true) { _ in
            self.currentSpamRate = Double(self.rateCounter)
            if self.currentSpamRate > self.peakSpamRate {
                self.peakSpamRate = self.currentSpamRate
            }
            self.rateCounter = 0
        }
    }
    
    func stopTracking() {
        isTracking = false
        rateTimer?.invalidate()
        rateTimer = nil
    }
    
    func recordSend(targetName: String) {
        totalSends += 1
        rateCounter += 1
        if targetsHit.insert(targetName).inserted {
            totalTargets = targetsHit.count
        }
    }
    
    func reset() {
        totalSends = 0
        totalTargets = 0
        sessionStartTime = nil
        peakSpamRate = 0
        currentSpamRate = 0
        targetsHit.removeAll()
        rateCounter = 0
    }
    
    var sessionDuration: TimeInterval {
        guard let start = sessionStartTime else { return 0 }
        return Date().timeIntervalSince(start)
    }
    
    var formattedDuration: String {
        let duration = sessionDuration
        let minutes = Int(duration) / 60
        let seconds = Int(duration) % 60
        return String(format: "%02d:%02d", minutes, seconds)
    }
}

// MARK: - Speed Mode Enum
enum SpamSpeedMode: String, CaseIterable, Identifiable {
    case slow = "Slow"
    case normal = "Normal"
    case fast = "Fast"
    case turbo = "Turbo"
    case burst = "BURST"
    
    var id: String { self.rawValue }
    
    var rechargeDuration: TimeInterval {
        switch self {
        case .slow: return 2.0
        case .normal: return 0.8
        case .fast: return 0.35
        case .turbo: return 0.15
        case .burst: return 0.05
        }
    }
    
    var icon: String {
        switch self {
        case .slow: return "tortoise.fill"
        case .normal: return "hare"
        case .fast: return "bolt.fill"
        case .turbo: return "bolt.heart.fill"
        case .burst: return "flame.fill"
        }
    }
    
    var color: Color {
        switch self {
        case .slow: return .blue
        case .normal: return .green
        case .fast: return .orange
        case .turbo: return .red
        case .burst: return .purple
        }
    }
    
    var description: String {
        switch self {
        case .slow: return "Chậm & ổn định"
        case .normal: return "Tốc độ tiêu chuẩn"
        case .fast: return "Nhanh - Khó chịu max"
        case .turbo: return "Cực nhanh - Màn hình liên tục hiện"
        case .burst: return "BURST - Spam không ngừng nghỉ!"
        }
    }
}

// MARK: - Preset Image Manager
class PresetManager {
    static let shared = PresetManager()
    
    let presets: [(name: String, filename: String)] = [
        ("Troll Face", "Trollface"),
        ("Shocked", "Preset1"),
        ("Rage", "Preset2"),
        ("LOL", "Preset3"),
        ("WTF", "Preset4"),
        ("Deal With It", "Preset5"),
        ("Mind Blown", "Preset6")
    ]
    
    func urlForPreset(named filename: String) -> URL? {
        Bundle.main.url(forResource: filename, withExtension: "png")
    }
    
    func allPresetURLs() -> [URL] {
        presets.compactMap { urlForPreset(named: $0.filename) }
    }
}

// MARK: - Multi-File Queue Manager
class FileQueueManager: ObservableObject {
    static let shared = FileQueueManager()
    
    @Published var queue: [URL] = []
    @Published var currentIndex: Int = 0
    @Published var isCircularMode: Bool = true
    
    func addFile(_ url: URL) {
        queue.append(url)
    }
    
    func removeFile(at index: Int) {
        guard index < queue.count else { return }
        queue.remove(at: index)
        if currentIndex >= queue.count {
            currentIndex = 0
        }
    }
    
    func clearQueue() {
        queue.removeAll()
        currentIndex = 0
    }
    
    func nextFile() -> URL? {
        guard !queue.isEmpty else { return nil }
        let url = queue[currentIndex]
        currentIndex += 1
        if currentIndex >= queue.count {
            currentIndex = isCircularMode ? 0 : queue.count - 1
        }
        return url
    }
    
    func reset() {
        currentIndex = 0
    }
}
