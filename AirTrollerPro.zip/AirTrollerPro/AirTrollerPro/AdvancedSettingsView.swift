//
//  AdvancedSettingsView.swift
//  AirTroller Pro
//
//  Settings for power users
//

import SwiftUI

struct AdvancedSettingsView: View {
    @Binding var burstMode: Bool
    @Binding var autoRetarget: Bool
    @Binding var useMultiFileMode: Bool
    @Binding var deviceSpoofName: String
    @Environment(\.presentationMode) var presentationMode
    
    @State private var showResetAlert = false
    
    var body: some View {
        NavigationView {
            List {
                // MARK: - Speed & Mode Section
                Section(header: Text("Chế độ Spam").foregroundColor(.orange)) {
                    Toggle(isOn: $burstMode) {
                        HStack {
                            Image(systemName: "flame.fill")
                                .foregroundColor(.purple)
                                .frame(width: 30)
                            VStack(alignment: .leading, spacing: 2) {
                                Text("Burst Mode")
                                    .fontWeight(.semibold)
                                Text("Spam liên tục không ngừng nghỉ - max speed")
                                    .font(.caption)
                                    .foregroundColor(.secondary)
                            }
                        }
                    }
                    .tint(.purple)
                    
                    Toggle(isOn: $autoRetarget) {
                        HStack {
                            Image(systemName: "scope")
                                .foregroundColor(.blue)
                                .frame(width: 30)
                            VStack(alignment: .leading, spacing: 2) {
                                Text("Auto-Retarget")
                                    .fontWeight(.semibold)
                                Text("Tự động spam thiết bị mới khi phát hiện")
                                    .font(.caption)
                                    .foregroundColor(.secondary)
                            }
                        }
                    }
                    .tint(.blue)
                }
                
                // MARK: - Multi-File Section
                Section(header: Text("Multi-File").foregroundColor(.purple)) {
                    Toggle(isOn: $useMultiFileMode) {
                        HStack {
                            Image(systemName: "doc.on.doc.fill")
                                .foregroundColor(.purple)
                                .frame(width: 30)
                            VStack(alignment: .leading, spacing: 2) {
                                Text("Queue Mode")
                                    .fontWeight(.semibold)
                                Text("Luân phiên gửi nhiều file khác nhau")
                                    .font(.caption)
                                    .foregroundColor(.secondary)
                            }
                        }
                    }
                    .tint(.purple)
                    
                    if useMultiFileMode {
                        NavigationLink(destination: QueueManagerView()) {
                            HStack {
                                Image(systemName: "list.bullet.rectangle.fill")
                                    .foregroundColor(.purple)
                                Text("Quản lý hàng đợi file")
                                Spacer()
                                Text("\(FileQueueManager.shared.queue.count) files")
                                    .foregroundColor(.secondary)
                            }
                        }
                    }
                }
                
                // MARK: - Device Spoofing
                Section(header: Text("Ẩn danh").foregroundColor(.red)) {
                    VStack(alignment: .leading, spacing: 8) {
                        HStack {
                            Image(systemName: "theatermasks.fill")
                                .foregroundColor(.red)
                            Text("Tên thiết bị giả")
                                .fontWeight(.semibold)
                        }
                        
                        TextField("Để trống = dùng tên thật", text: $deviceSpoofName)
                            .textFieldStyle(RoundedBorderTextFieldStyle())
                            .autocapitalization(.none)
                        
                        Text("Tên này sẽ hiển thị trên thiết bị ngườinhận")
                            .font(.caption)
                            .foregroundColor(.secondary)
                    }
                }
                
                // MARK: - Tips Section
                Section(header: Text("Mẹo sử dụng").foregroundColor(.green)) {
                    VStack(alignment: .leading, spacing: 12) {
                        TipRow(icon: "bolt.fill", title: "Speed", desc: "Chọn 'Turbo' hoặc 'Burst' để spam nhanh nhất")
                        TipRow(icon: "person.2.fill", title: "Multi-target", desc: "Chọn nhiều thiết bị cùng lúc để spam đồng loạt")
                        TipRow(icon: "photo.stack", title: "Queue", desc: "Thêm nhiều ảnh vào hàng đợi để luân phiên gửi")
                        TipRow(icon: "wifi", title: "Range", desc: "AirDrop chỉ hoạt động trong phạm vi ~10 mét")
                        TipRow(icon: "hand.raised.fill", title: "Caution", desc: "Spam quá nhiều có thể bị chặn AirDrop tạm thờ")
                    }
                }
                
                // MARK: - About
                Section(header: Text("Thông tin").foregroundColor(.orange)) {
                    HStack {
                        Text("Phiên bản")
                        Spacer()
                        Text("2.0.0 Pro")
                            .foregroundColor(.secondary)
                    }
                    
                    HStack {
                        Text("Engine")
                        Spacer()
                        Text("Sharing.framework")
                            .foregroundColor(.secondary)
                    }
                    
                    HStack {
                        Text("Yêu cầu")
                        Spacer()
                        Text("iOS 14.0+ / TrollStore / Jailbreak")
                            .foregroundColor(.secondary)
                    }
                }
            }
            .listStyle(InsetGroupedListStyle())
            .navigationTitle("Cài đặt nâng cao")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Xong") {
                        presentationMode.wrappedValue.dismiss()
                    }
                    .fontWeight(.bold)
                    .foregroundColor(.orange)
                }
            }
        }
    }
}

// MARK: - Tip Row
struct TipRow: View {
    let icon: String
    let title: String
    let desc: String
    
    var body: some View {
        HStack(alignment: .top, spacing: 10) {
            Image(systemName: icon)
                .foregroundColor(.orange)
                .frame(width: 24)
            
            VStack(alignment: .leading, spacing: 2) {
                Text(title)
                    .font(.subheadline)
                    .fontWeight(.semibold)
                Text(desc)
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
        }
    }
}
