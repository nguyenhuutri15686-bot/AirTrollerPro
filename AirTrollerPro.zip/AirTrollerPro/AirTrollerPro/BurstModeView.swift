//
//  BurstModeView.swift
//  AirTroller Pro
//
//  Specialized burst mode interface
//

import SwiftUI

struct BurstModeView: View {
    @Environment(\.presentationMode) var presentationMode
    @ObservedObject private var stats = StatsManager.shared
    
    @State private var isActive = false
    @State private var intensity: Double = 0.5
    @State private var selectedDuration: BurstDuration = .unlimited
    
    enum BurstDuration: String, CaseIterable, Identifiable {
        case thirty = "30s"
        case oneMinute = "1 phút"
        case fiveMinutes = "5 phút"
        case unlimited = "Không giới hạn"
        
        var id: String { self.rawValue }
        var timeInterval: TimeInterval? {
            switch self {
            case .thirty: return 30
            case .oneMinute: return 60
            case .fiveMinutes: return 300
            case .unlimited: return nil
            }
        }
    }
    
    var body: some View {
        NavigationView {
            ZStack {
                // Animated background when active
                if isActive {
                    BurstBackground()
                }
                
                VStack(spacing: 24) {
                    // Status ring
                    ZStack {
                        Circle()
                            .stroke(Color.purple.opacity(0.2), lineWidth: 20)
                            .frame(width: 200, height: 200)
                        
                        Circle()
                            .trim(from: 0, to: isActive ? 1 : 0)
                            .stroke(
                                AngularGradient(
                                    gradient: Gradient(colors: [.purple, .red, .orange, .purple]),
                                    center: .center
                                ),
                                style: StrokeStyle(lineWidth: 20, lineCap: .round)
                            )
                            .frame(width: 200, height: 200)
                            .rotationEffect(.degrees(-90))
                            .animation(.easeInOut(duration: 2).repeatForever(autoreverses: false), value: isActive)
                        
                        VStack(spacing: 4) {
                            if isActive {
                                Image(systemName: "flame.fill")
                                    .font(.system(size: 40))
                                    .foregroundColor(.purple)
                                    .modifier(PulseEffect())
                                Text("BURSTING")
                                    .font(.title3)
                                    .fontWeight(.black)
                                    .foregroundColor(.purple)
                            } else {
                                Image(systemName: "bolt.circle.fill")
                                    .font(.system(size: 40))
                                    .foregroundColor(.secondary)
                                Text("SẴN SÀNG")
                                    .font(.title3)
                                    .fontWeight(.bold)
                                    .foregroundColor(.secondary)
                            }
                        }
                    }
                    
                    // Stats when active
                    if isActive {
                        HStack(spacing: 20) {
                            BurstStat(value: "\(stats.totalSends)", label: "Sent")
                            BurstStat(value: "\(Int(stats.currentSpamRate))", label: "Rate/m")
                            BurstStat(value: stats.formattedDuration, label: "Time")
                        }
                    }
                    
                    // Controls
                    VStack(spacing: 16) {
                        // Intensity slider
                        VStack(alignment: .leading, spacing: 8) {
                            Text("Cường độ: \(Int(intensity * 100))%")
                                .font(.subheadline)
                                .fontWeight(.semibold)
                            Slider(value: $intensity, in: 0.1...1.0, step: 0.1)
                                .tint(.purple)
                        }
                        
                        // Duration picker
                        VStack(alignment: .leading, spacing: 8) {
                            Text("Thờigian")
                                .font(.subheadline)
                                .fontWeight(.semibold)
                            Picker("Duration", selection: $selectedDuration) {
                                ForEach(BurstDuration.allCases) { duration in
                                    Text(duration.rawValue).tag(duration)
                                }
                            }
                            .pickerStyle(SegmentedPickerStyle())
                        }
                    }
                    .padding()
                    .background(Color(UIColor.secondarySystemFill))
                    .cornerRadius(16)
                    .padding(.horizontal)
                    
                    Spacer()
                    
                    // Big toggle button
                    Button(action: { isActive.toggle() }) {
                        HStack {
                            Image(systemName: isActive ? "stop.fill" : "bolt.fill")
                                .font(.title2)
                            Text(isActive ? "DỪNG BURST" : "KÍCH HOẠT BURST")
                                .font(.headline)
                                .fontWeight(.black)
                        }
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 20)
                        .background(
                            isActive
                                ? LinearGradient(colors: [.red, .red.opacity(0.8)], startPoint: .leading, endPoint: .trailing)
                                : LinearGradient(colors: [.purple, .red], startPoint: .leading, endPoint: .trailing)
                        )
                        .cornerRadius(16)
                        .shadow(color: (isActive ? Color.red : Color.purple).opacity(0.5), radius: 10)
                    }
                    .padding(.horizontal)
                }
                .padding(.vertical)
            }
            .navigationTitle("Burst Mode")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Xong") {
                        presentationMode.wrappedValue.dismiss()
                    }
                    .fontWeight(.bold)
                }
            }
        }
    }
}

// MARK: - Burst Stat
struct BurstStat: View {
    let value: String
    let label: String
    
    var body: some View {
        VStack(spacing: 4) {
            Text(value)
                .font(.title2)
                .fontWeight(.black)
                .foregroundColor(.purple)
            Text(label)
                .font(.caption)
                .foregroundColor(.secondary)
        }
        .frame(width: 80)
        .padding(.vertical, 12)
        .background(Color.purple.opacity(0.1))
        .cornerRadius(12)
    }
}

// MARK: - Burst Background Animation
struct BurstBackground: View {
    @State private var phase = 0.0
    
    var body: some View {
        TimelineView(.animation(minimumInterval: 0.05)) { _ in
            Canvas { context, size in
                let center = CGPoint(x: size.width / 2, y: size.height / 2)
                for i in 0..<12 {
                    let angle = Double(i) * .pi / 6 + phase
                    let radius = 50 + sin(phase * 2 + Double(i)) * 30
                    let pos = CGPoint(
                        x: center.x + cos(angle) * radius,
                        y: center.y + sin(angle) * radius
                    )
                    let rect = CGRect(x: pos.x - 3, y: pos.y - 3, width: 6, height: 6)
                    context.fill(Path(ellipseIn: rect), with: .color(.purple.opacity(0.3)))
                }
            }
            .onAppear {
                withAnimation(.linear(duration: 3).repeatForever(autoreverses: false)) {
                    phase = .pi * 2
                }
            }
        }
    }
}
