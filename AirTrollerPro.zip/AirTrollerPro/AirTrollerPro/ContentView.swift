//
//  ContentView.swift
//  AirTroller Pro
//
//  Enhanced main UI with tabs and advanced controls
//

import SwiftUI
import Photos

struct ContentView: View {
    @StateObject private var trollController = TrollController(
        sharedURL: Bundle.main.url(forResource: "Trollface", withExtension: "png")!,
        rechargeDuration: 0.5
    )
    @StateObject private var fileQueue = FileQueueManager.shared
    @StateObject private var stats = StatsManager.shared
    
    @State private var selectedTab = 0
    @State private var selectedPeople: [TDKSFNode: Bool] = [:]
    @State private var selectedSpeedMode: SpamSpeedMode = .normal
    @State private var totalAirDrops: Int = 0
    @State private var showingImagePicker = false
    @State private var showingQueueSheet = false
    @State private var showingPresetsSheet = false
    @State private var showingStatsSheet = false
    @State private var showingSettingsSheet = false
    @State private var showingSpeedPicker = false
    @State private var customImageURL: URL?
    @State private var useMultiFileMode = false
    @State private var burstMode = false
    @State private var autoRetarget = false
    @State private var deviceSpoofName = ""
    @State private var showingDeviceNameAlert = false
    
    private var gridItemLayout = [GridItem(.adaptive(minimum: 80, maximum: 110))]
    
    var body: some View {
        NavigationView {
            ZStack {
                // Background gradient
                LinearGradient(
                    gradient: Gradient(colors: [Color(.systemBackground), Color(.secondarySystemBackground)]),
                    startPoint: .top,
                    endPoint: .bottom
                )
                .ignoresSafeArea()
                
                VStack(spacing: 0) {
                    // MARK: - Device Scanner Area
                    deviceListSection
                    
                    Divider()
                        .padding(.horizontal)
                    
                    // MARK: - Control Panel
                    controlPanel
                }
            }
            .navigationTitle("AirTroller Pro")
            .navigationBarTitleDisplayMode(.large)
            .toolbar {
                ToolbarItemGroup(placement: .navigationBarTrailing) {
                    // Speed mode indicator
                    Button(action: { showingSpeedPicker = true }) {
                        HStack(spacing: 4) {
                            Image(systemName: selectedSpeedMode.icon)
                                .foregroundColor(selectedSpeedMode.color)
                            Text(selectedSpeedMode.rawValue)
                                .font(.caption)
                                .fontWeight(.bold)
                                .foregroundColor(selectedSpeedMode.color)
                        }
                        .padding(.horizontal, 10)
                        .padding(.vertical, 6)
                        .background(selectedSpeedMode.color.opacity(0.15))
                        .cornerRadius(16)
                    }
                    
                    // Stats button
                    Button(action: { showingStatsSheet = true }) {
                        ZStack {
                            Image(systemName: "chart.bar.fill")
                                .font(.system(size: 20))
                            if stats.isTracking {
                                Circle()
                                    .fill(Color.red)
                                    .frame(width: 8, height: 8)
                                    .offset(x: 8, y: -8)
                            }
                        }
                    }
                }
            }
            .sheet(isPresented: $showingImagePicker) {
                ImagePickerView(imageURL: $customImageURL)
            }
            .sheet(isPresented: $showingQueueSheet) {
                QueueManagerView()
            }
            .sheet(isPresented: $showingPresetsSheet) {
                PresetImagesView(selectedURL: $customImageURL)
            }
            .sheet(isPresented: $showingStatsSheet) {
                StatsView()
            }
            .sheet(isPresented: $showingSettingsSheet) {
                AdvancedSettingsView(
                    burstMode: $burstMode,
                    autoRetarget: $autoRetarget,
                    useMultiFileMode: $useMultiFileMode,
                    deviceSpoofName: $deviceSpoofName
                )
            }
            .actionSheet(isPresented: $showingSpeedPicker) {
                ActionSheet(
                    title: Text("Chọn chế độ tốc độ"),
                    message: Text("Tốc độ càng cao, spam càng nhiều nhưng có thể bị chặn"),
                    buttons: SpamSpeedMode.allCases.map { mode in
                        .default(Text("\(Image(systemName: mode.icon)) \(mode.rawValue) - \(mode.description)")) {
                            selectedSpeedMode = mode
                            trollController.rechargeDuration = mode.rechargeDuration
                        }
                    } + [.cancel()]
                )
            }
            .onAppear {
                trollController.startBrowser()
            }
            .onDisappear {
                if trollController.isRunning {
                    trollController.stopTrollings()
                }
                trollController.stopBrowser()
            }
            .onChange(of: selectedSpeedMode) { newMode in
                trollController.rechargeDuration = newMode.rechargeDuration
            }
        }
        .navigationViewStyle(StackNavigationViewStyle())
    }
    
    // MARK: - Device List Section
    private var deviceListSection: some View {
        Group {
            if trollController.people.count == 0 {
                // Empty state - scanning
                VStack(spacing: 16) {
                    Spacer()
                    ZStack {
                        Circle()
                            .fill(Color.orange.opacity(0.1))
                            .frame(width: 120, height: 120)
                        Circle()
                            .stroke(Color.orange.opacity(0.3), lineWidth: 2)
                            .frame(width: 120, height: 120)
                            .scaleEffect(1.2)
                            .opacity(0.5)
                            .animation(Animation.easeInOut(duration: 1.5).repeatForever(autoreverses: true), value: UUID())
                        
                        Image(systemName: "dot.radiowaves.left.and.right")
                            .font(.system(size: 40))
                            .foregroundColor(.orange)
                    }
                    
                    Text("Đang quét thiết bị...")
                        .font(.headline)
                        .foregroundColor(.secondary)
                    
                    Text("Đảm bảo Bluetooth và WiFi đã bật\nvà thiết bị mục tiêu ở gần")
                        .font(.caption)
                        .foregroundColor(.secondary)
                        .multilineTextAlignment(.center)
                    
                    Spacer()
                }
                .frame(maxHeight: .infinity)
            } else {
                // Device grid
                VStack(alignment: .leading, spacing: 8) {
                    HStack {
                        Text("Thiết bị phát hiện (\(trollController.people.count))")
                            .font(.headline)
                            .fontWeight(.bold)
                        
                        Spacer()
                        
                        // Select All button
                        Button(action: selectAllDevices) {
                            Text(selectedCount == trollController.people.count ? "Bỏ chọn" : "Chọn tất cả")
                                .font(.caption)
                                .fontWeight(.semibold)
                                .foregroundColor(.orange)
                        }
                    }
                    .padding(.horizontal)
                    .padding(.top, 8)
                    
                    ScrollView {
                        LazyVGrid(columns: gridItemLayout, spacing: 12) {
                            ForEach(
                                trollController.people.sorted(by: {
                                    ($0.displayName ?? "") < ($1.displayName ?? "")
                                }),
                                id: \.node
                            ) { person in
                                EnhancedPersonView(
                                    person: person,
                                    isSelected: Binding(
                                        get: { selectedPeople[person.node] ?? false },
                                        set: { selectedPeople[person.node] = $0 }
                                    ),
                                    isRunning: trollController.isRunning
                                )
                            }
                        }
                        .padding(.horizontal)
                    }
                }
            }
        }
    }
    
    // MARK: - Control Panel
    private var controlPanel: some View {
        VStack(spacing: 12) {
            // Stats bar when running
            if trollController.isRunning {
                HStack {
                    StatBadge(icon: "paperplane.fill", value: "\(stats.totalSends)", label: "Đã gửi")
                    StatBadge(icon: "person.3.fill", value: "\(stats.totalTargets)", label: "Mục tiêu")
                    StatBadge(icon: "clock.fill", value: stats.formattedDuration, label: "Thờigian")
                    if stats.currentSpamRate > 0 {
                        StatBadge(icon: "bolt.fill", value: "\(Int(stats.currentSpamRate))/p", label: "Tốcđộ", color: .green)
                    }
                }
                .padding(.horizontal, 8)
                .padding(.top, 8)
            }
            
            // File selection row
            HStack(spacing: 12) {
                // Custom image button
                Button(action: {
                    if customImageURL != nil {
                        customImageURL = nil
                    } else {
                        showingImagePicker = true
                    }
                }) {
                    HStack {
                        Image(systemName: customImageURL == nil ? "photo" : "checkmark.circle.fill")
                        Text(customImageURL == nil ? "Chọn ảnh" : (customImageURL!.lastPathComponent.prefix(15) + "..."))
                            .lineLimit(1)
                    }
                    .font(.subheadline)
                    .padding(.horizontal, 12)
                    .padding(.vertical, 10)
                    .background(Color(UIColor.secondarySystemFill))
                    .foregroundColor(customImageURL == nil ? .primary : .green)
                    .cornerRadius(10)
                }
                
                // Presets button
                Button(action: { showingPresetsSheet = true }) {
                    HStack {
                        Image(systemName: "square.grid.2x2")
                        Text("Presets")
                    }
                    .font(.subheadline)
                    .padding(.horizontal, 12)
                    .padding(.vertical, 10)
                    .background(Color.orange.opacity(0.15))
                    .foregroundColor(.orange)
                    .cornerRadius(10)
                }
                
                // Queue button
                Button(action: { showingQueueSheet = true }) {
                    HStack {
                        Image(systemName: "list.bullet.rectangle.fill")
                        if fileQueue.queue.count > 0 {
                            Text("\(fileQueue.queue.count)")
                                .font(.caption2)
                                .fontWeight(.bold)
                                .padding(4)
                                .background(Color.red)
                                .foregroundColor(.white)
                                .clipShape(Circle())
                        }
                    }
                    .font(.subheadline)
                    .padding(.horizontal, 12)
                    .padding(.vertical, 10)
                    .background(Color.purple.opacity(0.15))
                    .foregroundColor(.purple)
                    .cornerRadius(10)
                }
            }
            
            // Burst mode toggle
            if burstMode {
                HStack {
                    Image(systemName: "flame.fill")
                        .foregroundColor(.purple)
                    Text("BURST MODE ACTIVE")
                        .font(.caption)
                        .fontWeight(.black)
                        .foregroundColor(.purple)
                    Spacer()
                    // Pulsing indicator
                    Circle()
                        .fill(Color.purple)
                        .frame(width: 8, height: 8)
                        .modifier(PulseEffect())
                }
                .padding(.horizontal, 12)
                .padding(.vertical, 8)
                .background(Color.purple.opacity(0.1))
                .cornerRadius(8)
                .overlay(
                    RoundedRectangle(cornerRadius: 8)
                        .stroke(Color.purple.opacity(0.3), lineWidth: 1)
                )
            }
            
            // Main action button
            Button(action: toggleTrolling) {
                HStack {
                    Image(systemName: trollController.isRunning ? "stop.circle.fill" : "paperplane.circle.fill")
                        .font(.title2)
                    Text(trollController.isRunning ? "DỪNG SPAM" : "BẮT ĐẦU SPAM")
                        .font(.headline)
                        .fontWeight(.black)
                }
                .foregroundColor(.white)
                .frame(maxWidth: .infinity)
                .padding(.vertical, 16)
                .background(
                    LinearGradient(
                        gradient: Gradient(colors: trollController.isRunning 
                            ? [Color.red.opacity(0.8), Color.red]
                            : [Color.orange.opacity(0.8), Color.orange, Color.red.opacity(0.8)]
                        ),
                        startPoint: .leading,
                        endPoint: .trailing
                    )
                )
                .cornerRadius(14)
                .shadow(color: (trollController.isRunning ? Color.red : Color.orange).opacity(0.4), radius: 8, x: 0, y: 4)
            }
            .disabled(selectedCount == 0 && !trollController.isRunning)
            .opacity(selectedCount == 0 && !trollController.isRunning ? 0.6 : 1)
            
            // Bottom toolbar
            HStack {
                Button(action: { showingSettingsSheet = true }) {
                    VStack(spacing: 4) {
                        Image(systemName: "gearshape.2.fill")
                        Text("Nâng cao")
                            .font(.caption2)
                    }
                    .foregroundColor(.secondary)
                }
                
                Spacer()
                
                // Selected count
                if selectedCount > 0 {
                    Text("\(selectedCount) mục tiêu")
                        .font(.caption)
                        .foregroundColor(.orange)
                        .fontWeight(.semibold)
                }
                
                Spacer()
                
                Button(action: restartBrowser) {
                    VStack(spacing: 4) {
                        Image(systemName: "arrow.clockwise.circle.fill")
                        Text("Làm mới")
                            .font(.caption2)
                    }
                    .foregroundColor(.secondary)
                }
            }
            .padding(.horizontal)
            .padding(.bottom, 8)
        }
        .padding(.horizontal)
        .padding(.vertical, 8)
        .background(Color(UIColor.systemBackground).opacity(0.95))
    }
    
    // MARK: - Helpers
    private var selectedCount: Int {
        selectedPeople.values.filter { $0 }.count
    }
    
    private func selectAllDevices() {
        let allSelected = selectedCount == trollController.people.count
        for person in trollController.people {
            selectedPeople[person.node] = !allSelected
        }
        UIImpactFeedbackGenerator(style: .light).impactOccurred()
    }
    
    private func restartBrowser() {
        UIImpactFeedbackGenerator(style: .medium).impactOccurred()
        trollController.stopBrowser()
        selectedPeople.removeAll()
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
            trollController.startBrowser()
        }
    }
    
    private func toggleTrolling() {
        UIImpactFeedbackGenerator(style: .heavy).impactOccurred()
        
        if !trollController.isRunning {
            guard selectedCount > 0 else {
                UIApplication.shared.alert(title: "Chưa chọn mục tiêu", body: "Hãy chọn ít nhất một thiết bị để spam!")
                return
            }
            
            // Confirmation alert
            UIApplication.shared.confirmAlert(
                title: "Bắt đầu spam?",
                body: "Thiết bị: \(UIDevice.current.name)\nMục tiêu: \(selectedCount)\nChế độ: \(selectedSpeedMode.rawValue)\(burstMode ? " + BURST" : "")\n\nSpam AirDrop sẽ gửi liên tục đến thiết bị đã chọn!",
                onOK: startSpamming,
                noCancel: false
            )
        } else {
            stopSpamming()
        }
    }
    
    private func startSpamming() {
        // Set the file to share
        if let customURL = customImageURL {
            trollController.sharedURL = customURL
        } else if useMultiFileMode && !fileQueue.queue.isEmpty {
            fileQueue.reset()
            if let nextURL = fileQueue.nextFile() {
                trollController.sharedURL = nextURL
            }
        } else {
            trollController.sharedURL = Bundle.main.url(forResource: "Trollface", withExtension: "png")!
        }
        
        // Apply burst mode if enabled
        if burstMode {
            trollController.rechargeDuration = SpamSpeedMode.burst.rechargeDuration
        } else {
            trollController.rechargeDuration = selectedSpeedMode.rechargeDuration
        }
        
        // Start stats tracking
        stats.reset()
        stats.startTracking()
        
        // Apply device spoofing if set
        if !deviceSpoofName.isEmpty {
            trollController.spoofedDeviceName = deviceSpoofName
        }
        
        // Start trolling
        trollController.startTrolling(
            shouldTrollHandler: { person in
                selectedPeople[person.node] ?? false
            },
            eventHandler: { event in
                handleTrollEvent(event)
            }
        )
        
        trollController.isRunning = true
    }
    
    private func stopSpamming() {
        trollController.stopTrollings()
        trollController.isRunning = false
        stats.stopTracking()
        
        // Show summary
        if stats.totalSends > 0 {
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                UIApplication.shared.alert(
                    title: "Spam hoàn thành!",
                    body: "Tổng số lần gửi: \(stats.totalSends)\nThiết bị bị spam: \(stats.totalTargets)\nThờigian: \(stats.formattedDuration)\nTốc độ cao nhất: \(Int(stats.peakSpamRate))/phút"
                )
            }
        }
    }
    
    private func handleTrollEvent(_ event: TrollController.TrollEvent) {
        switch event {
        case .operationEvent(let opEvent):
            if opEvent == .canceled || opEvent == .finished || opEvent == .blocked {
                totalAirDrops += 1
                stats.recordSend(targetName: "target_\(totalAirDrops)")
                UISelectionFeedbackGenerator().selectionChanged()
                
                // Multi-file mode: rotate to next file
                if useMultiFileMode && !fileQueue.queue.isEmpty {
                    if let nextURL = fileQueue.nextFile() {
                        trollController.sharedURL = nextURL
                    }
                }
            }
        case .cancelled:
            totalAirDrops += 1
            stats.recordSend(targetName: "target_\(totalAirDrops)")
            UISelectionFeedbackGenerator().selectionChanged()
        }
    }
}

// MARK: - Enhanced Person View
struct EnhancedPersonView: View {
    let person: TrollController.Person
    @Binding var isSelected: Bool
    let isRunning: Bool
    
    var body: some View {
        Button(action: {
            if !isRunning {
                UIImpactFeedbackGenerator(style: .light).impactOccurred()
                isSelected.toggle()
            }
        }) {
            VStack(spacing: 8) {
                ZStack {
                    // Background circle
                    Circle()
                        .fill(isSelected 
                            ? LinearGradient(gradient: Gradient(colors: [.orange, .red]), startPoint: .topLeading, endPoint: .bottomTrailing)
                            : LinearGradient(gradient: Gradient(colors: [Color(UIColor.tertiarySystemFill)]), startPoint: .topLeading, endPoint: .bottomTrailing)
                        )
                        .frame(width: 64, height: 64)
                    
                    // Icon
                    Image(systemName: isSelected ? "ant.fill" : "iphone")
                        .font(.system(size: 28))
                        .foregroundColor(isSelected ? .white : .secondary)
                }
                .overlay(
                    Circle()
                        .stroke(isSelected ? Color.red.opacity(0.5) : Color.clear, lineWidth: 2)
                        .scaleEffect(1.1)
                )
                
                Text(person.displayName ?? "Unknown")
                    .font(.caption)
                    .fontWeight(isSelected ? .bold : .regular)
                    .foregroundColor(isSelected ? .orange : .primary)
                    .lineLimit(2)
                    .multilineTextAlignment(.center)
                    .minimumScaleFactor(0.7)
            }
            .padding(6)
            .background(Color(UIColor.secondarySystemFill).opacity(0.5))
            .cornerRadius(12)
            .overlay(
                RoundedRectangle(cornerRadius: 12)
                    .stroke(isSelected ? Color.orange.opacity(0.6) : Color.clear, lineWidth: 2)
            )
        }
        .disabled(isRunning)
        .opacity(isRunning && !isSelected ? 0.5 : 1)
    }
}

// MARK: - Stat Badge
struct StatBadge: View {
    let icon: String
    let value: String
    let label: String
    var color: Color = .orange
    
    var body: some View {
        VStack(spacing: 4) {
            HStack(spacing: 4) {
                Image(systemName: icon)
                    .font(.caption)
                    .foregroundColor(color)
                Text(value)
                    .font(.caption)
                    .fontWeight(.bold)
                    .foregroundColor(.primary)
            }
            Text(label)
                .font(.caption2)
                .foregroundColor(.secondary)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 8)
        .background(Color(UIColor.tertiarySystemFill))
        .cornerRadius(10)
    }
}

// MARK: - Pulse Effect Modifier
struct PulseEffect: ViewModifier {
    @State private var isPulsing = false
    
    func body(content: Content) -> some View {
        content
            .scaleEffect(isPulsing ? 1.5 : 0.8)
            .opacity(isPulsing ? 0.3 : 1)
            .animation(Animation.easeInOut(duration: 0.8).repeatForever(autoreverses: true), value: isPulsing)
            .onAppear { isPulsing = true }
    }
}

// MARK: - Preview
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
