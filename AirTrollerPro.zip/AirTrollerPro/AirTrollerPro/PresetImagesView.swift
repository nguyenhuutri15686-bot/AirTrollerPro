//
//  PresetImagesView.swift
//  AirTroller Pro
//
//  Pre-built troll images selection
//

import SwiftUI

struct PresetImagesView: View {
    @Binding var selectedURL: URL?
    @Environment(\.presentationMode) var presentationMode
    
    private let presets = PresetManager.shared.presets
    @State private var selectedPreset: String? = nil
    
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(spacing: 16) {
                    // Header
                    VStack(spacing: 8) {
                        Image(systemName: "photo.on.rectangle.angled")
                            .font(.system(size: 40))
                            .foregroundColor(.orange)
                        Text("Chọn ảnh có sẵn")
                            .font(.title2)
                            .fontWeight(.bold)
                        Text("Những ảnh preset được tối ưu cho việc troll")
                            .font(.caption)
                            .foregroundColor(.secondary)
                            .multilineTextAlignment(.center)
                    }
                    .padding(.top)
                    
                    // Presets grid
                    LazyVGrid(columns: [
                        GridItem(.flexible()),
                        GridItem(.flexible()),
                        GridItem(.flexible())
                    ], spacing: 16) {
                        ForEach(presets, id: \.filename) { preset in
                            PresetCard(
                                name: preset.name,
                                filename: preset.filename,
                                isSelected: selectedPreset == preset.filename
                            )
                            .onTapGesture {
                                selectPreset(named: preset.filename)
                            }
                        }
                    }
                    .padding(.horizontal)
                    
                    // Tip
                    VStack(alignment: .leading, spacing: 8) {
                        Label("Mẹo: Bạn cũng có thể dùng ảnh tùy chỉnh từ thư viện ảnh", systemImage: "lightbulb.fill")
                            .font(.caption)
                            .foregroundColor(.orange)
                    }
                    .padding()
                    .background(Color.orange.opacity(0.1))
                    .cornerRadius(12)
                    .padding(.horizontal)
                    
                    Spacer(minLength: 40)
                }
            }
            .navigationTitle("Preset Images")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("Hủy") {
                        presentationMode.wrappedValue.dismiss()
                    }
                }
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Xong") {
                        presentationMode.wrappedValue.dismiss()
                    }
                    .fontWeight(.bold)
                    .foregroundColor(.orange)
                }
            }
        }
    }
    
    private func selectPreset(named filename: String) {
        UIImpactFeedbackGenerator(style: .light).impactOccurred()
        selectedPreset = filename
        selectedURL = PresetManager.shared.urlForPreset(named: filename)
    }
}

// MARK: - Preset Card
struct PresetCard: View {
    let name: String
    let filename: String
    let isSelected: Bool
    
    var body: some View {
        VStack(spacing: 8) {
            // Image preview
            ZStack {
                RoundedRectangle(cornerRadius: 12)
                    .fill(Color(UIColor.secondarySystemFill))
                    .aspectRatio(1, contentMode: .fit)
                
                // Placeholder - will show actual image if available
                VStack {
                    Image(systemName: iconForPreset(name))
                        .font(.system(size: 36))
                        .foregroundColor(.orange)
                    Text(name)
                        .font(.caption)
                        .foregroundColor(.secondary)
                        .lineLimit(1)
                }
                
                // Selection overlay
                if isSelected {
                    RoundedRectangle(cornerRadius: 12)
                        .fill(Color.orange.opacity(0.3))
                    
                    Image(systemName: "checkmark.circle.fill")
                        .font(.system(size: 30))
                        .foregroundColor(.orange)
                        .shadow(radius: 2)
                }
            }
            .overlay(
                RoundedRectangle(cornerRadius: 12)
                    .stroke(isSelected ? Color.orange : Color.clear, lineWidth: 3)
            )
        }
    }
    
    private func iconForPreset(_ name: String) -> String {
        switch name {
        case "Troll Face": return "face.smiling.inverse"
        case "Shocked": return "exclamationmark.octagon.fill"
        case "Rage": return "flame.fill"
        case "LOL": return "face.laughing.fill"
        case "WTF": return "questionmark.circle.fill"
        case "Deal With It": return "sunglasses.fill"
        case "Mind Blown": return "bolt.circle.fill"
        default: return "photo"
        }
    }
}

// MARK: - Queue Manager View
struct QueueManagerView: View {
    @Environment(\.presentationMode) var presentationMode
    @ObservedObject private var fileQueue = FileQueueManager.shared
    @State private var showingImagePicker = false
    @State private var tempImageURL: URL?
    
    var body: some View {
        NavigationView {
            List {
                // Info section
                Section {
                    VStack(alignment: .leading, spacing: 8) {
                        Label("Hàng đợi multi-file", systemImage: "info.circle.fill")
                            .font(.headline)
                            .foregroundColor(.purple)
                        Text("Các file trong hàng đợi sẽ được gửi luân phiên khi spam. Bật 'Queue Mode' trong cài đặt để sử dụng.")
                            .font(.caption)
                            .foregroundColor(.secondary)
                    }
                    .padding(.vertical, 4)
                }
                
                // Add button
                Section {
                    Button(action: { showingImagePicker = true }) {
                        HStack {
                            Image(systemName: "plus.circle.fill")
                                .foregroundColor(.purple)
                            Text("Thêm ảnh vào hàng đợi")
                                .fontWeight(.semibold)
                        }
                    }
                    
                    // Add presets section
                    Button(action: addAllPresets) {
                        HStack {
                            Image(systemName: "photo.stack.fill")
                                .foregroundColor(.orange)
                            Text("Thêm tất cả presets")
                                .fontWeight(.semibold)
                        }
                    }
                }
                
                // Queue items
                Section(header: Text("\(fileQueue.queue.count) files trong hàng đợi")) {
                    if fileQueue.queue.isEmpty {
                        Text("Hàng đợi trống")
                            .foregroundColor(.secondary)
                            .italic()
                    } else {
                        ForEach(0..<fileQueue.queue.count, id: \.self) { index in
                            QueueItemRow(
                                index: index + 1,
                                filename: fileQueue.queue[index].lastPathComponent,
                                isCurrent: index == fileQueue.currentIndex
                            )
                        }
                        .onDelete(perform: deleteItems)
                    }
                }
                
                // Settings
                if !fileQueue.queue.isEmpty {
                    Section {
                        Toggle("Chế độ vòng lặp", isOn: $fileQueue.isCircularMode)
                            .tint(.purple)
                    }
                    
                    Section {
                        Button(role: .destructive, action: { fileQueue.clearQueue() }) {
                            Label("Xóa toàn bộ hàng đợi", systemImage: "trash.fill")
                        }
                    }
                }
            }
            .listStyle(InsetGroupedListStyle())
            .navigationTitle("Quản lý hàng đợi")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Xong") {
                        presentationMode.wrappedValue.dismiss()
                    }
                    .fontWeight(.bold)
                    .foregroundColor(.purple)
                }
            }
            .sheet(isPresented: $showingImagePicker) {
                ImagePickerView(imageURL: Binding(
                    get: { tempImageURL },
                    set: { newURL in
                        tempImageURL = newURL
                        if let url = newURL {
                            fileQueue.addFile(url)
                        }
                    }
                ))
            }
        }
    }
    
    private func deleteItems(at offsets: IndexSet) {
        for index in offsets {
            fileQueue.removeFile(at: index)
        }
    }
    
    private func addAllPresets() {
        UIImpactFeedbackGenerator(style: .light).impactOccurred()
        for preset in PresetManager.shared.presets {
            if let url = PresetManager.shared.urlForPreset(named: preset.filename) {
                fileQueue.addFile(url)
            }
        }
    }
}

// MARK: - Queue Item Row
struct QueueItemRow: View {
    let index: Int
    let filename: String
    let isCurrent: Bool
    
    var body: some View {
        HStack {
            ZStack {
                Circle()
                    .fill(isCurrent ? Color.purple : Color(UIColor.tertiarySystemFill))
                    .frame(width: 28, height: 28)
                
                if isCurrent {
                    Image(systemName: "play.fill")
                        .font(.caption)
                        .foregroundColor(.white)
                } else {
                    Text("\(index)")
                        .font(.caption)
                        .fontWeight(.bold)
                        .foregroundColor(.secondary)
                }
            }
            
            VStack(alignment: .leading, spacing: 2) {
                Text(filename)
                    .font(.subheadline)
                    .lineLimit(1)
                
                if isCurrent {
                    Text("Đang phát")
                        .font(.caption2)
                        .foregroundColor(.purple)
                        .fontWeight(.semibold)
                }
            }
            
            Spacer()
            
            Image(systemName: "photo")
                .foregroundColor(.secondary)
        }
        .padding(.vertical, 2)
        .background(isCurrent ? Color.purple.opacity(0.05) : Color.clear)
    }
}
