#!/bin/bash
# Build script cho AirTroller Pro
# Chạy trên macOS với Xcode đã cài

set -e

PROJECT_NAME="AirTrollerPro"
APP_NAME="AirTrollerPro"
BUNDLE_ID="com.yourname.airtrollerpro"

echo "=========================================="
echo "  AirTroller Pro - Build Script"
echo "=========================================="

# Kiểm tra môi trường
if ! command -v xcodebuild &> /dev/null; then
    echo "❌ ERROR: xcodebuild không tìm thấy!"
    echo "Hãy cài Xcode từ App Store."
    exit 1
fi

if ! xcodebuild -checkFirstLaunchStatus 2>/dev/null; then
    echo "⚠️  Xcode chưa được cấu hình. Hãy mở Xcode và đợi cài đặt hoàn tất."
    exit 1
fi

echo ""
echo "📱 Bắt đầu build $APP_NAME..."
echo ""

# Tạo build directory
BUILD_DIR="build"
rm -rf "$BUILD_DIR"
mkdir -p "$BUILD_DIR"

# Bước 1: Tạo Xcode project tạm thờ nếu chưa có
if [ ! -d "$APP_NAME.xcodeproj" ]; then
    echo "📁 Tạo Xcode project..."
    
    # Dùng xcodebuild để tạo project
    mkdir -p Sources
    
    # Copy all source files
    cp AirTrollerPro/*.swift Sources/ 2>/dev/null || true
    cp trolldrop/*.swift Sources/ 2>/dev/null || true
    cp Misc/*.swift Sources/ 2>/dev/null || true
    cp Misc/TS/*.h Sources/ 2>/dev/null || true  
    cp Misc/TS/*.m Sources/ 2>/dev/null || true
    
    # Tạo SPM package
    cat > Package.swift << EOF
// swift-tools-version:5.5
import PackageDescription

let package = Package(
    name: "$APP_NAME",
    platforms: [.iOS(.v14)],
    products: [.executable(name: "$APP_NAME", targets: ["$APP_NAME"])],
    targets: [.executableTarget(name: "$APP_NAME", path: "Sources")]
)
EOF
    
    echo "⚠️  Không tìm thấy .xcodeproj"
    echo "Hãy tạo project thủ công trong Xcode hoặc dùng GitHub Actions."
    exit 1
fi

# Bước 2: Build
echo "🔨 Đang build..."
xcodebuild \
    -project "$APP_NAME.xcodeproj" \
    -scheme "$APP_NAME" \
    -configuration Release \
    -destination 'generic/platform=iOS' \
    -derivedDataPath "$BUILD_DIR/DerivedData" \
    CODE_SIGNING_ALLOWED=NO \
    CODE_SIGNING_REQUIRED=NO \
    CODE_SIGN_IDENTITY="" \
    ENABLE_BITCODE=NO \
    ARCHS="arm64 arm64e" \
    ONLY_ACTIVE_ARCH=NO \
    2>&1 | tee "$BUILD_DIR/build.log" | grep -E '(error|warning|BUILD|Signing|\.tipa|\.ipa)' || true

# Bước 3: Tìm app đã build
echo ""
echo "📦 Đang đóng gói..."

APP_PATH=$(find "$BUILD_DIR/DerivedData" -name "$APP_NAME.app" -type d 2>/dev/null | head -1)

if [ -z "$APP_PATH" ]; then
    echo "❌ Không tìm thấy file .app đã build!"
    echo "Kiểm tra log tại: $BUILD_DIR/build.log"
    exit 1
fi

echo "✅ Tìm thấy: $APP_PATH"

# Bước 4: Tạo Payload và đóng gói
mkdir -p "$BUILD_DIR/Payload"
cp -R "$APP_PATH" "$BUILD_DIR/Payload/"

# Xóa signature nếu có (cho TrollStore)
rm -rf "$BUILD_DIR/Payload/$APP_NAME.app/_CodeSignature"

# Tạo .ipa (zip với Payload)
cd "$BUILD_DIR"
zip -qr "../$APP_NAME.tipa" Payload/
cd ..

# Kiểm tra kết quả
if [ -f "$APP_NAME.tipa" ]; then
    SIZE=$(ls -lh "$APP_NAME.tipa" | awk '{print $5}')
    echo ""
    echo "=========================================="
    echo "  ✅ BUILD THÀNH CÔNG!"
    echo "=========================================="
    echo ""
    echo "📁 File: $APP_NAME.tipa"
    echo "📏 Kích thước: $SIZE"
    echo ""
    echo "📲 Cách cài đặt:"
    echo "   1. Copy $APP_NAME.tipa sang iPhone"
    echo "   2. Mở bằng TrollStore"
    echo "   3. Nhấn Install"
    echo ""
    echo "🔥 Sẵn sàng troll!"
else
    echo "❌ Đóng gói thất bại!"
    exit 1
fi
