// Placeholder - Person is now defined inside TrollController.swift
// This file is kept for compatibility
