#ifndef _REMOTE_LOG_H_
#define _REMOTE_LOG_H_

#import <Foundation/Foundation.h>
#import <netinet/in.h>
#import <sys/socket.h>
#import <unistd.h>
#import <arpa/inet.h>

// Remote logging disabled by default for release builds
#ifndef DEBUG
#define REMOTE_LOG_ENABLED 0
#else
#define REMOTE_LOG_ENABLED 0  // Set to 1 to enable remote logging in debug
#endif

#define RLOG_IP_ADDRESS "192.168.1.100"
#define RLOG_PORT 11909

__attribute__((unused)) static void RLogv(NSString* format, va_list args)
{
    #if REMOTE_LOG_ENABLED
        NSString* str = [[NSString alloc] initWithFormat:format arguments:args];
        NSLog(@"[AirTrollerPro] %@", str);

        int sd = socket(PF_INET, SOCK_DGRAM, IPPROTO_UDP);
        if (sd <= 0) return;

        int broadcastEnable = 1;
        setsockopt(sd, SOL_SOCKET, SO_BROADCAST, &broadcastEnable, sizeof(broadcastEnable));

        struct sockaddr_in broadcastAddr;
        memset(&broadcastAddr, 0, sizeof broadcastAddr);
        broadcastAddr.sin_family = AF_INET;
        inet_pton(AF_INET, RLOG_IP_ADDRESS, &broadcastAddr.sin_addr);
        broadcastAddr.sin_port = htons(RLOG_PORT);

        char* request = (char*)[str UTF8String];
        sendto(sd, request, strlen(request), 0, (struct sockaddr*)&broadcastAddr, sizeof broadcastAddr);
        close(sd);
    #else
        (void)format;
        (void)args;
    #endif
}

__attribute__((unused)) static void RLog(NSString* format, ...)
{
    #if REMOTE_LOG_ENABLED
        va_list args;
        va_start(args, format);
        RLogv(format, args);
        va_end(args);
    #else
        (void)format;
    #endif
}
#endif
