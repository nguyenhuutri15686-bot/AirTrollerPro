//
//  Extensions.swift
//  AirTroller Pro
//
//  Useful extensions
//

import UIKit
import SwiftUI

extension Color {
    init(uiColor14 uiColor: UIColor) {
        if #available(iOS 15.0, *) {
            self.init(uiColor: uiColor)
        } else {
            var red: CGFloat = 0
            var green: CGFloat = 0
            var blue: CGFloat = 0
            var alpha: CGFloat = 0
            uiColor.getRed(&red, green: &green, blue: &blue, alpha: &alpha)
            self.init(red: Double(red), green: Double(green), blue: Double(blue), opacity: Double(alpha))
        }
    }
}

extension UIApplication {
    func open(_ url: URL) {
        guard canOpenURL(url) else { return }
        open(url, options: [:], completionHandler: nil)
    }
}
