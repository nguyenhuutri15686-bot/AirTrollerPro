#!/bin/bash
# Script tạo Xcode project cho AirTroller Pro
# Chạy trên macOS với Xcode đã cài đặt

set -e

echo "=========================================="
echo "  AirTroller Pro - Project Generator"
echo "=========================================="

# Kiểm tra xcodebuild
if ! command -v xcodebuild &> /dev/null; then
    echo "ERROR: xcodebuild không tìm thấy. Hãy cài Xcode từ App Store."
    exit 1
fi

PROJECT_NAME="AirTrollerPro"
BUNDLE_ID="com.yourname.airtrollerpro"

echo ""
echo "Tạo Xcode project '$PROJECT_NAME'..."

# Tạo project structure
mkdir -p "$PROJECT_NAME"

# Tạo Xcode project dùng xcodebuild
cat > "project_config.plist" << 'EOF'
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>projectName</key>
    <string>AirTrollerPro</string>
    <key>bundleIdentifier</key>
    <string>com.yourname.airtrollerpro</string>
    <key>deploymentTarget</key>
    <string>14.0</string>
    <key>devices</key>
    <array>
        <string>iPhone</string>
        <string>iPad</string>
    </array>
</dict>
</plist>
EOF

echo "Tạo project với Swift package..."

# Tạo Package.swift để dùng SPM
cat > "Package.swift" << 'EOF'
// swift-tools-version:5.5
import PackageDescription

let package = Package(
    name: "AirTrollerPro",
    platforms: [.iOS(.v14)],
    products: [
        .executable(name: "AirTrollerPro", targets: ["AirTrollerPro"])
    ],
    targets: [
        .executableTarget(
            name: "AirTrollerPro",
            path: "Sources",
            swiftSettings: [
                .define("DEBUG", .when(configuration: .debug))
            ]
        )
    ]
)
EOF

# Tạo source structure
mkdir -p Sources
cp -R AirTrollerPro/*.swift Sources/ 2>/dev/null || true
cp -R trolldrop/*.swift Sources/ 2>/dev/null || true
cp -R Misc/*.swift Sources/ 2>/dev/null || true
cp Misc/TS/*.h Sources/ 2>/dev/null || true
cp Misc/TS/*.m Sources/ 2>/dev/null || true

echo ""
echo "=========================================="
echo "  Hướng dẫn Build thủ công trên macOS"
echo "=========================================="
echo ""
echo "Vì project cần private frameworks, bạn cần build qua Xcode:"
echo ""
echo "1. Mở Finder, tạo folder mới tên 'AirTrollerProProject'"
echo ""
echo "2. Copy TẤT CẢ các file .swift vào folder:"
echo "   - AirTrollerPro/*.swift"
echo "   - trolldrop/*.swift"
echo "   - Misc/*.swift"
echo "   - Misc/TS/*.h và *.m"
echo ""
echo "3. Mở Xcode → Create New Project → iOS App"
echo "   - Product Name: AirTrollerPro"
echo "   - Organization: yourname"
echo "   - Interface: SwiftUI"
echo "   - Language: Swift"
echo "   - Minimum iOS: 14.0"
echo ""
echo "4. Trong Xcode, xóa các file mẫu (ContentView.swift, etc)"
echo "   rồi Add Existing Files tất cả file .swift đã copy"
echo ""
echo "5. Thêm Bridging Header:"
echo "   - Tạo file 'AirTrollerPro-Bridging-Header.h'"
echo "   - Trong Build Settings, set 'Objective-C Bridging Header'"
echo "     thành \$(SRCROOT)/AirTrollerPro-Bridging-Header.h"
echo ""
echo "6. Set entitlements:"
echo "   - Copy nội dung AirTrollerPro.entitlements"
echo "   - Vào Signing & Capabilities, import file này"
echo ""
echo "7. Build (Cmd+B) hoặc Archive (Cmd+Shift+A)"
echo ""
echo "8. Export .ipa rồi đổi tên thành .tipa"
echo ""
echo "=========================================="
echo "  HOẶC đơn giản hơn: Dùng GitHub Actions!"
echo "=========================================="
echo ""
echo "1. Tạo repository mới trên GitHub"
echo "2. Upload toàn bộ code lên"
echo "3. GitHub sẽ tự động build .tipa cho bạn!"
echo "   (File .github/workflows/build.yml đã có sẵn)"
echo ""
EOF

chmod +x create_project.sh

echo ""
echo "DONE! Đọc hướng dẫn ở trên để build."
